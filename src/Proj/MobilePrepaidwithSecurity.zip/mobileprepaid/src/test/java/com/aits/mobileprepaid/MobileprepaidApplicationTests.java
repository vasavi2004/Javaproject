package com.aits.mobileprepaid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileprepaidApplicationTests {

	@Test
	void contextLoads() {
	}

}
